{
    'name':"Recurring Subscription ",
    'author':'odoo',
    'version':'17.0.3.0',
    'category':'reccuring',
    'summary':'Subscription',
    'depends':['base',
               'product'
               ],
    'license': 'GPL-2',
    'sequence':-104,
    'installation': True,
    'application': True,
    'data':[
        'security/ir.model.access.csv',
        'views/recurring_subscription_view.xml',
        'views/recurring_credit_view.xml',
        'data/seq_recurring_subscription.xml',
        'data/product.xml',
        'views/billing_schedule_view.xml',
        ],
}